import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [temp, setTemp] = useState('Waiting for Temp');

  useEffect(() => {
    const fetchTemperature = async () => {
      try {
        const response = await fetch('http://localhost:3000/health-data'); // Replace with your server's IP address and endpoint
        const data = await response.json();

        if (data && data.temperature) {
          setTemp(data.temperature);
        } else {
          setTemp('No Data Available');
        }
      } catch (error) {
        console.error('Error fetching temperature data:', error);
        setTemp('Error fetching data');
      }
    };

    // Fetch temperature data every 3 seconds
    const intervalId = setInterval(fetchTemperature, 2000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  return (
    <>
      <div>The temperature is {temp}</div>
    </>
  );
}

export default App;
